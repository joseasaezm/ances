###############################################################
###############################################################
###############################################################

if(!require(UBL)) install.packages("UBL")
if(!require(FNN)) install.packages("FNN")
if(!require(GenSA)) install.packages("GenSA")

library(UBL)
library(FNN)
library(GenSA)

###############################################################
###############################################################
###############################################################

ComputePerformance <- function(res){
  
  res$real <- as.character(res$real)
  res$pred <- as.character(res$pred)
  
  classes <- unique(res$real)
  
  TPR <- c()
  for(c in classes){
    resfoldclass <- res[res$real == c,]
    tprc <- sum(resfoldclass$real == resfoldclass$pred) / nrow(resfoldclass)
    TPR <- c(TPR, tprc)
  }
  
  GM <- prod(TPR) ^ (1/length(classes))
  return(GM)
}

###############################################################
###############################################################
###############################################################

fitness <- function(train, test, kpar){
  
  poscla <- ncol(train)
  nn <- get.knnx(data = train[,-poscla], query = test[,-poscla], k = (kpar+1), algorithm = "kd_tree")$nn.index

  if(kpar > 1)
    nn <- nn[,2:ncol(nn)]
  else
    nn <- as.matrix(nn,nrow=nrow(train),ncol = 1)
  
  pred <- c()
  for(i in 1:nrow(test)){
    cmaj <- which.max(table(train[nn[i,],poscla]))
    pred <- c(pred, names(cmaj))
  }
  pred <- as.factor(pred)
  
  results <- data.frame(real = test[, poscla], pred = pred)
  
  res <- ComputePerformance(results)
  return(res)
}

###############################################################
###############################################################
###############################################################

fitnessANCES <- function(x, pos_, dataD_, dataV_, k1){
  
  for(i in 1:nrow(pos_)){
    dataD_[pos_[i,1],pos_[i,2]] <- x[i]
  }
  
  # minimize
  perf_ <- 1 - fitness(dataD_, dataV_, k1)
  
  return(perf_)
}

###############################################################
###############################################################
###############################################################

ANCES <- function(data, k1, k2, p, itmax, itimp){
  
  dataV <- data
  
  stop <- FALSE
  it <- 1
  iter_noimp <- 0
  bestFitness <- fitness(data, data, k1)
  
  dataDout <- data
  
  while(!stop){
    
    ########################################################################
    ###################### compute error score #############################
    ########################################################################
    
    nn <- neighbours(ncol(data), data, dist = "Euclidean", k = k2)
    datanew <- matrix(data = 0, nrow = nrow(data), ncol = ncol(data)-1)
    for(i in 1:nrow(datanew)){
      for(j in 1:ncol(datanew)){
        nni <- nn[i,]
        datanew[i,j] <- mean(data[nni,j])
      }
    }
    features <- as.data.frame(datanew)
    data_aux <- cbind(features, data[,ncol(data)])
    names(data_aux)[ncol(data_aux)] <- names(data)[ncol(data)]
    datanew <- data_aux
    
    # compute difference
    data_dif <- abs(data[,-ncol(data)] - datanew[,-ncol(datanew)])
    
    # select first changesIt values
    changesIt <- nrow(data)*ncol(data)*p
    order_dif <- order(data_dif, decreasing = TRUE)
    pos <- arrayInd(order_dif, dim(data_dif), useNames = TRUE)
    pos <- pos[1:changesIt,]
    
    ########################################################################
    ###################### optimization ####################################
    ########################################################################
    
    initValues <- rep(0, nrow(pos))
    for(v in 1:nrow(pos)){
      initValues[v] <- data[pos[v,1],pos[v,2]]
    }
    resSA <- GenSA(par = initValues, fn = fitnessANCES, pos_ = pos, dataD_ = data,
          dataV_ = dataV, k1 = k1,
          lower = rep(0, nrow(pos)), upper = rep(1, nrow(pos)),
          control = list(max.call = 100, trace.mat = FALSE))
    x <- resSA$par

    # create optimized data
    Dopt <- data
    for(v in 1:nrow(pos)){
      Dopt[pos[v,1],pos[v,2]] <- x[v]
    }
    
    fitness_it <- fitness(Dopt, dataV, k1)
    
    ########################################################################
    ###################### update datasets #################################
    ########################################################################

    if(fitness_it > bestFitness){
      bestFitness <- fitness_it
      dataV <- Dopt
      dataDout <- Dopt
      
      iter_noimp <- 1
    }
    else{
      iter_noimp <- iter_noimp + 1
    }
    
    data <- Dopt
    
    ########################################################################
    ###################### stopping criterion ##############################
    ########################################################################
    
    it <- it + 1
    if( it > itmax | iter_noimp > itimp ){
      stop <- TRUE
    }
  }
  
  return(dataDout)
}

###############################################################
###############################################################
###############################################################
